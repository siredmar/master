/* module.h

   written by Marc Singer
   28 Jun 2008

   Copyright (C) 2008 Marc Singer

   -----------
   DESCRIPTION
   -----------

*/

#if !defined (__MODULE_H__)
#    define   __MODULE_H__

/* ----- Includes */

/* ----- Types */

/* ----- Globals */

/* ----- Prototypes */

#define EXPORT_SYMBOL(a)


#endif  /* __MODULE_H__ */
