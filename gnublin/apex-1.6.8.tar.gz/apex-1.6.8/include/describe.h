/* describe.h

   written by Marc Singer
   21 Dec 2008

   Copyright (C) 2008 Marc Singer

   -----------
   DESCRIPTION
   -----------

*/

#if !defined (__DESCRIBE_H__)
#    define   __DESCRIBE_H__

/* ----- Includes */

/* ----- Types */

/* ----- Globals */

/* ----- Prototypes */

const char* describe_size (uint32_t cb);

#endif  /* __DESCRIBE_H__ */
