using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.Text;

namespace LPCDisplay
{
    [StructLayout(LayoutKind.Sequential)]
    public struct BITFIELDS
    {
        public uint BlueMask;
        public uint GreenMask;
        public uint RedMask;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct BITMAPV5HEADER
    {
        [FieldOffset(0)]
        public uint bV5Size;
        [FieldOffset(4)]
        public int bV5Width;
        [FieldOffset(8)]
        public int bV5Height;
        [FieldOffset(12)]
        public ushort bV5Planes;
        [FieldOffset(14)]
        public ushort bV5BitCount;
        [FieldOffset(16)]
        public uint bV5Compression;
        [FieldOffset(20)]
        public uint bV5SizeImage;
        [FieldOffset(24)]
        public int bV5XPelsPerMeter;
        [FieldOffset(28)]
        public int bV5YPelsPerMeter;
        [FieldOffset(32)]
        public uint bV5ClrUsed;
        [FieldOffset(36)]
        public uint bV5ClrImportant;
        [FieldOffset(40)]
        public uint bV5RedMask;
        [FieldOffset(44)]
        public uint bV5GreenMask;
        [FieldOffset(48)]
        public uint bV5BlueMask;
        [FieldOffset(52)]
        public uint bV5AlphaMask;
        [FieldOffset(56)]
        public uint bV5CSType;
        [FieldOffset(60)]
        public CIEXYZTRIPLE bV5Endpoints;
        [FieldOffset(96)]
        public uint bV5GammaRed;
        [FieldOffset(100)]
        public uint bV5GammaGreen;
        [FieldOffset(104)]
        public uint bV5GammaBlue;
        [FieldOffset(108)]
        public uint bV5Intent;
        [FieldOffset(112)]
        public uint bV5ProfileData;
        [FieldOffset(116)]
        public uint bV5ProfileSize;
        [FieldOffset(120)]
        public uint bV5Reserved;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct CIEXYZ
    {
        public uint ciexyzX; //FXPT2DOT30
        public uint ciexyzY; //FXPT2DOT30
        public uint ciexyzZ; //FXPT2DOT30
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct CIEXYZTRIPLE
    {
        public CIEXYZ ciexyzRed;
        public CIEXYZ ciexyzGreen;
        public CIEXYZ ciexyzBlue;
    }

    /// <summary>
	/// This class shall keep the GDI32 APIs being used in our program.
	/// </summary>
	public class PlatformInvokeGDI32
	{


        public const uint CBM_INIT = 0x04;
        public const uint DIB_RGB_COLORS = 0;
        public const int BI_RGB = 0;
        public const int BI_BITFIELDS = 3;
        public const int LCS_WINDOWS_COLOR_SPACE = 2;
        public const int LCS_GM_IMAGES = 4;
        public const int CF_DIB = 8;
        public const int CF_DIBV5 = 17;
        public const int GMEM_MOVEABLE = 0x00000002;
        public const int GMEM_ZEROINIT = 0x00000040;
        public const int GMEM_DDESHARE = 0x00002000;
        public const int GHND = GMEM_MOVEABLE | GMEM_ZEROINIT;
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        // INNER TYPES
        /////////////////////////////////////////////////////////////////////////////////////////////////////



 
       #region Class Variables
		public  const int SRCCOPY = 13369376;
		#endregion

		#region Class Functions
		[DllImport("gdi32.dll",EntryPoint="DeleteDC")]
		public static extern IntPtr DeleteDC(IntPtr hDc);

		[DllImport("gdi32.dll",EntryPoint="DeleteObject")]
		public static extern IntPtr DeleteObject(IntPtr hDc);

		[DllImport("gdi32.dll",EntryPoint="BitBlt")]
		public static extern bool BitBlt(IntPtr hdcDest,int xDest,int yDest,int wDest,int hDest,IntPtr hdcSource,int xSrc,int ySrc,int RasterOp);

		[DllImport ("gdi32.dll",EntryPoint="CreateCompatibleBitmap")]
		public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc,	int nWidth, int nHeight);

		[DllImport ("gdi32.dll",EntryPoint="CreateCompatibleDC")]
		public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("gdi32.dll", EntryPoint = "CreateDIBSection")]
        public static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPV5HEADER bmi, uint Usage, [In][Out] ref IntPtr ppvBits, IntPtr hSection, uint dwOffset); 
        //static extern IntPtr CreateDIBitmap(IntPtr hdc, [In] ref BITMAPV5HEADER lpbmih, uint fdwInit, ref byte[] lpbInit, [In] ref BITMAPV5HEADER lpbmi, uint fuUsage);

        [DllImport ("gdi32.dll",EntryPoint="SelectObject")]
		public static extern IntPtr SelectObject(IntPtr hdc, IntPtr bmp);

       
        #endregion
	
		#region Public Constructor
		public PlatformInvokeGDI32()
		{
			// 
			// TODO: Add constructor logic here
			//
		}
		#endregion
	
	}
}
