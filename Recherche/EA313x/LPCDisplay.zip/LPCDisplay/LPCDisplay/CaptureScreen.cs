using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.Text;

namespace LPCDisplay
{
	/// <summary>
	/// This class shall keep all the functionality for capturing 
	/// the desktop.
	/// </summary>
	public class CaptureScreen
	{
        public const int LPC_DISP_WD = 240;
        public const int LPC_DISP_HT = 320;
        public const int LPC_DISP_SZ = LPC_DISP_WD * LPC_DISP_HT * 2;

        #region Public Class Functions
        public static void GetDesktopImage(ref byte[] frameBuf)
		{
			//In size variable we shall keep the size of the screen.
			SIZE size;
			
			//Variable to keep the handle to bitmap.
			IntPtr hBitmap;

			//Here we get the handle to the desktop device context.
			IntPtr 	hDC = PlatformInvokeUSER32.GetDC(PlatformInvokeUSER32.GetDesktopWindow()); 

			//Here we make a compatible device context in memory for screen device context.
			IntPtr hMemDC = PlatformInvokeGDI32.CreateCompatibleDC(hDC);
			
			//We pass SM_CXSCREEN constant to GetSystemMetrics to get the X coordinates of screen.
			size.cx = PlatformInvokeUSER32.GetSystemMetrics(PlatformInvokeUSER32.SM_CXSCREEN);

			//We pass SM_CYSCREEN constant to GetSystemMetrics to get the Y coordinates of screen.
			size.cy = PlatformInvokeUSER32.GetSystemMetrics(PlatformInvokeUSER32.SM_CYSCREEN);
			
			//We create a compatible bitmap of screen size using screen device context.
            //hBitmap = PlatformInvokeGDI32.CreateCompatibleBitmap(hDC, size.cx, size.cy);
            BITMAPV5HEADER bmi = new BITMAPV5HEADER();
            bmi.bV5Size = (uint)Marshal.SizeOf(typeof(BITMAPV5HEADER));
            bmi.bV5Width = LPC_DISP_WD;
            bmi.bV5Height = LPC_DISP_HT;
            bmi.bV5BitCount = 16;
            bmi.bV5Planes = 1;
            bmi.bV5Compression = PlatformInvokeGDI32.BI_BITFIELDS;
            bmi.bV5XPelsPerMeter = 0;
            bmi.bV5YPelsPerMeter = 0;
            bmi.bV5ClrUsed = 0;
            bmi.bV5ClrImportant = 0;
            bmi.bV5BlueMask = 0x0000001F;
            bmi.bV5GreenMask = 0x000007E0;
            bmi.bV5RedMask = 0x0000F800;
            bmi.bV5AlphaMask = 0x00000000;
            bmi.bV5CSType = PlatformInvokeGDI32.LCS_WINDOWS_COLOR_SPACE;
            bmi.bV5GammaBlue = 0;
            bmi.bV5GammaGreen = 0;
            bmi.bV5GammaRed = 0;
            bmi.bV5ProfileData = 0;
            bmi.bV5ProfileSize = 0;
            bmi.bV5Reserved = 0;
            bmi.bV5Intent = PlatformInvokeGDI32.LCS_GM_IMAGES;
            bmi.bV5SizeImage = (uint)LPC_DISP_SZ;
            bmi.bV5Endpoints.ciexyzBlue.ciexyzX = bmi.bV5Endpoints.ciexyzBlue.ciexyzY = bmi.bV5Endpoints.ciexyzBlue.ciexyzZ = 0;
            bmi.bV5Endpoints.ciexyzGreen.ciexyzX = bmi.bV5Endpoints.ciexyzGreen.ciexyzY = bmi.bV5Endpoints.ciexyzGreen.ciexyzZ = 0;
            bmi.bV5Endpoints.ciexyzRed.ciexyzX = bmi.bV5Endpoints.ciexyzRed.ciexyzY = bmi.bV5Endpoints.ciexyzRed.ciexyzZ = 0;

            IntPtr bits = IntPtr.Zero;
            hBitmap = PlatformInvokeGDI32.CreateDIBSection(hDC, ref bmi, PlatformInvokeGDI32.DIB_RGB_COLORS, ref bits, IntPtr.Zero, 0);

			//As hBitmap is IntPtr we can not check it against null. For this purspose IntPtr.Zero is used.
			if (hBitmap!=IntPtr.Zero)
			{
				//Here we select the compatible bitmap in memeory device context and keeps the refrence to Old bitmap.
				IntPtr hOld = (IntPtr) PlatformInvokeGDI32.SelectObject(hMemDC, hBitmap);
				//We copy the Bitmap to the memory device context.
                PlatformInvokeGDI32.BitBlt(hMemDC, 0, 0, LPC_DISP_WD, LPC_DISP_HT, hDC, 40, 40, PlatformInvokeGDI32.SRCCOPY);

                Marshal.Copy(bits, frameBuf, 0, LPC_DISP_SZ); 
 
				//We select the old bitmap back to the memory device context.
				PlatformInvokeGDI32.SelectObject(hMemDC, hOld);
				//We delete the memory device context.
				PlatformInvokeGDI32.DeleteDC(hMemDC);
				//We release the screen device context.
				PlatformInvokeUSER32.ReleaseDC(PlatformInvokeUSER32.GetDesktopWindow(), hDC);
				//Image is created by Image bitmap handle and stored in local variable.
				//Bitmap bmp = System.Drawing.Image.FromHbitmap(hBitmap); 
				//Release the memory for compatible bitmap.
				PlatformInvokeGDI32.DeleteObject(hBitmap);
				//This statement runs the garbage collector manually.
				//GC.Collect();
				//Return the bitmap 
				//return bmp;
			}
		
			//If hBitmap is null retunrn null.
			//return null;
		}
 		#endregion
	}
}
