﻿namespace LPCDisplay
{
    partial class LPCDispFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ConButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bulkSendBut = new System.Windows.Forms.Button();
            this.rcvBox = new System.Windows.Forms.TextBox();
            this.sendBox = new System.Windows.Forms.TextBox();
            this.DevStatusLable = new System.Windows.Forms.Label();
            this.SyncButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ConButton
            // 
            this.ConButton.Location = new System.Drawing.Point(377, 18);
            this.ConButton.Name = "ConButton";
            this.ConButton.Size = new System.Drawing.Size(75, 60);
            this.ConButton.TabIndex = 0;
            this.ConButton.Text = "Find LPC Device";
            this.ConButton.UseVisualStyleBackColor = true;
            this.ConButton.Click += new System.EventHandler(this.ConButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.bulkSendBut);
            this.groupBox1.Controls.Add(this.rcvBox);
            this.groupBox1.Controls.Add(this.sendBox);
            this.groupBox1.Location = new System.Drawing.Point(15, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(352, 269);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Loopback Bulk Endpoints";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Received Data";
            // 
            // bulkSendBut
            // 
            this.bulkSendBut.Location = new System.Drawing.Point(300, 23);
            this.bulkSendBut.Name = "bulkSendBut";
            this.bulkSendBut.Size = new System.Drawing.Size(46, 93);
            this.bulkSendBut.TabIndex = 2;
            this.bulkSendBut.Text = "Send";
            this.bulkSendBut.UseVisualStyleBackColor = true;
            this.bulkSendBut.Click += new System.EventHandler(this.bulkSendBut_Click);
            // 
            // rcvBox
            // 
            this.rcvBox.Location = new System.Drawing.Point(7, 167);
            this.rcvBox.Multiline = true;
            this.rcvBox.Name = "rcvBox";
            this.rcvBox.ReadOnly = true;
            this.rcvBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.rcvBox.Size = new System.Drawing.Size(286, 93);
            this.rcvBox.TabIndex = 1;
            // 
            // sendBox
            // 
            this.sendBox.Location = new System.Drawing.Point(7, 23);
            this.sendBox.Multiline = true;
            this.sendBox.Name = "sendBox";
            this.sendBox.Size = new System.Drawing.Size(286, 93);
            this.sendBox.TabIndex = 0;
            // 
            // DevStatusLable
            // 
            this.DevStatusLable.AutoSize = true;
            this.DevStatusLable.Location = new System.Drawing.Point(22, 324);
            this.DevStatusLable.Name = "DevStatusLable";
            this.DevStatusLable.Size = new System.Drawing.Size(74, 13);
            this.DevStatusLable.TabIndex = 2;
            this.DevStatusLable.Text = "Device Status";
            // 
            // SyncButton
            // 
            this.SyncButton.Enabled = false;
            this.SyncButton.Location = new System.Drawing.Point(377, 130);
            this.SyncButton.Name = "SyncButton";
            this.SyncButton.Size = new System.Drawing.Size(75, 62);
            this.SyncButton.TabIndex = 3;
            this.SyncButton.Text = "Sync Video";
            this.SyncButton.UseVisualStyleBackColor = true;
            this.SyncButton.Click += new System.EventHandler(this.SyncButton_Click);
            // 
            // LPCDispFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 361);
            this.Controls.Add(this.SyncButton);
            this.Controls.Add(this.DevStatusLable);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ConButton);
            this.Name = "LPCDispFrm";
            this.Text = "LPCDisplayForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LPCDisp_close);
            this.Load += new System.EventHandler(this.LPCDisp_open);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ConButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bulkSendBut;
        private System.Windows.Forms.TextBox rcvBox;
        private System.Windows.Forms.TextBox sendBox;
        private System.Windows.Forms.Label DevStatusLable;
        private System.Windows.Forms.Button SyncButton;
    }
}

