﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Timers;
using System.Runtime.InteropServices;
namespace LPCDisplay
{
    public partial class LPCDispFrm : Form
    {
        //  This GUID must match the GUID in the device's INF file.
        //  To create a GUID in Visual Studio, click Tools > Create GUID.

        private const String LPCDISPLAY_GUID_STRING = "{a01674b4-c5f6-485c-af94-3271701d57b4}";

        private IntPtr deviceNotificationHandle;
        private Boolean myDeviceDetected = false;
        private DeviceManagement myDeviceManagement = new DeviceManagement();
        private String myDevicePathName;
        private WinUsbDevice myWinUsbDevice = new WinUsbDevice();
        private static System.Timers.Timer myVideoTimer;
        private Byte[] frameBuf;
        internal LPCDispFrm frmMy;
        private Boolean syncFB = false;
        private Object thisLock = new Object();

        ///  <summary>
        ///  Define a class of delegates with the same parameters as 
        ///  WinUsbDevice.ReadViaBulkTransfer and WinUsbDevice.ReadViaInterruptTransfer.
        ///  Used for asynchronous reads from the device.
        ///  </summary>

        private delegate void ReadFromDeviceDelegate
            (Byte pipeID,
            UInt32 bufferLength,
            ref Byte[] buffer,
            ref UInt32 lengthTransferred,
            ref Boolean success);

        ///  <summary>
        ///  Define a delegate with the same parameters as AccessForm.
        ///  Used in accessing the application's form from a different thread.
        ///  </summary>

        private delegate void MarshalToForm(String action, String textToAdd);

        private delegate void TimerDelegate();

        public LPCDispFrm()
        {
            InitializeComponent();
            bulkSendBut.Enabled = false;
        }

        private void SendFB()
        {
            try
            {
                if (myDeviceDetected)
                {
                    lock (thisLock)
                    {

                        if (syncFB)
                        {
                            /* sync pattern */
                            frameBuf[0] = (Byte)'S';
                            frameBuf[1] = (Byte)'Y';
                            frameBuf[2] = (Byte)'N';
                            frameBuf[3] = (Byte)'C';

                            myWinUsbDevice.FlushPipe(myWinUsbDevice.myDevInfo.videoBulkOutPipe);
                            myWinUsbDevice.FlushPipe(myWinUsbDevice.myDevInfo.bulkOutPipe);

                            /* send Sync packet */
                            myWinUsbDevice.SendViaBulkTransfer
                                (System.Convert.ToByte(myWinUsbDevice.myDevInfo.bulkOutPipe),
                                ref frameBuf,
                                4);

                            syncFB = false;
                        }
                        else
                        {
                            CaptureScreen.GetDesktopImage(ref frameBuf);
                            myWinUsbDevice.SendViaBulkTransfer
                                (System.Convert.ToByte(myWinUsbDevice.myDevInfo.videoBulkOutPipe),
                                ref frameBuf,
                                CaptureScreen.LPC_DISP_SZ);
                        }

                    }
                }

            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        private void VideoTimerMethod(object source, ElapsedEventArgs e)
        {
            TimerDelegate fbDelegate = null;

            try
            {
                //  The AccessForm routine contains the code that accesses the form.
                fbDelegate = new TimerDelegate(SendFB);

                //  send new fb.
                base.BeginInvoke(fbDelegate, null);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
 
        private void InitVideoTimer()
        {
            // allocate frame buffer
            frameBuf = new Byte[CaptureScreen.LPC_DISP_SZ];
            // Create a timer with a ten second interval.
            myVideoTimer = new System.Timers.Timer(100);

            // Hook up the Elapsed event for the timer.
            myVideoTimer.Elapsed += new ElapsedEventHandler(VideoTimerMethod);

            // Set the Interval to get 20 frames per second.
            myVideoTimer.Interval = 50;

            GC.KeepAlive(myVideoTimer);
        }

        ///  <summary>
        ///  Performs various application-specific functions that
        ///  involve accessing the application's form.
        ///  </summary>
        ///  
        ///  <param name="action"> A String that names the action to perform on the form. </param>
        ///  <param name="formText"> Text to display on the form or an empty String. </param>
        ///  
        /// <remarks>
        ///  In asynchronous calls to WinUsb_ReadPipe, the callback function 
        ///  uses this routine to access the application's form, which runs in 
        ///  a different thread.
        /// </remarks>
        /// 
        private void AccessForm(String action, String formText)
        {
            try
            {
                //  Select an action to perform on the form:

                switch (action)
                {
                     case "AddItemToTextBox":
                        rcvBox.SelectedText = formText + "\r\n";
                        break;

                     case "EnableCmdSendandReceiveViaBulkTransfers":

                        bulkSendBut.Enabled = myDeviceDetected;
                        if(myDeviceDetected)
                            bulkSendBut.Focus();

                        break;
                     default:
                        break;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        ///  <summary>
        ///  Enables accessing a form from another thread 
        ///  </summary>
        ///  
        ///  <param name="action"> A String that names the action to perform on the form. </param>
        ///  <param name="textToDisplay"> Text that the form displays or uses for 
        ///  another purpose. Actions that don't use text ignore this parameter. </param>

        private void MyMarshalToForm(String action, String textToDisplay)
        {
            object[] args = { action, textToDisplay };
            MarshalToForm MarshalToFormDelegate = null;

            try
            {
                //  The AccessForm routine contains the code that accesses the form.

                MarshalToFormDelegate = new MarshalToForm(AccessForm);

                //  Execute AccessForm, passing the parameters in args.

                base.Invoke(MarshalToFormDelegate, args);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        ///  <summary>
        ///  Display the device's speed in the status lable.
        ///  </summary>
        ///  
        ///  <remarks>
        ///  Precondition: device speed was obtained by calling WinUsb_QueryDeviceInformation
        ///  and stored in myDevInfo. 
        ///  </remarks >

        private void DisplayDeviceSpeed()
        {
            String speed = "";

            myWinUsbDevice.QueryDeviceSpeed();

            try
            {
                switch (myWinUsbDevice.myDevInfo.devicespeed)
                {
                    case 1:
                        speed = "low";
                        break;
                    case 2:
                        speed = "full";
                        break;
                    case 3:
                        speed = "high";
                        break;
                }

                DevStatusLable.Text += speed;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        ///  <summary>
        ///  If a device with the specified device interface GUID hasn't been previously detected,
        ///  look for it. If found, open a handle to the device.
        ///  </summary>
        ///  
        ///  <returns>
        ///  True if the device is detected, False if not detected.
        ///  </returns>

        private Boolean FindMyDevice()
        {
            Boolean deviceFound;
            String devicePathName = "";
            Boolean success;

            try
            {
                if (!(myDeviceDetected))
                {

                    //  Convert the device interface GUID String to a GUID object: 

                    System.Guid winUsbDemoGuid =
                        new System.Guid(LPCDISPLAY_GUID_STRING);

                    // Fill an array with the device path names of all attached devices with matching GUIDs.

                    deviceFound = myDeviceManagement.FindDeviceFromGuid
                        (winUsbDemoGuid,
                        ref devicePathName);

                    if (deviceFound == true)
                    {
                        success = myWinUsbDevice.GetDeviceHandle(devicePathName);

                        if (success)
                        {
                            DevStatusLable.Text = "Device detected";

                            myDeviceDetected = true;
                            bulkSendBut.Enabled = true;
 
                            // Save DevicePathName so OnDeviceChange() knows which name is my device.

                            myDevicePathName = devicePathName;
                        }
                        else
                        {
                            // There was a problem in retrieving the information.
                            myVideoTimer.Enabled = false;
                            myDeviceDetected = false;
                            myWinUsbDevice.CloseDeviceHandle();
                            bulkSendBut.Enabled = false;
                        }
                    }

                    if (myDeviceDetected)
                    {

                        // The device was detected.
                        // Register to receive notifications if the device is removed or attached.

                        success = myDeviceManagement.RegisterForDeviceNotifications(
                            myDevicePathName,
                            frmMy.Handle,
                            winUsbDemoGuid,
                            ref deviceNotificationHandle);

                        if (success)
                        {
                            myWinUsbDevice.InitializeDevice();

                            //Commented out due to unreliable response from WinUsb_QueryDeviceInformation.                            
                            DisplayDeviceSpeed();
                            // now enable the timer for display
                            myVideoTimer.Enabled = true;
                            //VideoTimerMethod(null, null);
                        }
                    }
                    else
                    {
                        DevStatusLable.Text = "Device not found";
                    }
                }
                else
                {
                    DevStatusLable.Text = "Device detected";
                }

 
                return myDeviceDetected;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        ///  <summary>
        ///  Retrieves received data from a bulk endpoint.
        ///  This routine is called automatically when myWinUsbDevice.ReadViaBulkTransfer
        ///  returns. The routine calls several marshaling routines to access the main form.       
        ///  </summary>
        ///  
        ///  <param name="ar"> An object containing status information about the 
        ///  asynchronous operation.</param>
        ///  
        private void GetReceivedBulkData(IAsyncResult ar)
        {
            UInt32 bytesRead = 0;
            System.Text.ASCIIEncoding myEncoder = new System.Text.ASCIIEncoding();
            Byte[] receivedDataBuffer;
            String receivedtext = "";
            Boolean success = false;

            try
            {
                receivedDataBuffer = null;

                // Define a delegate using the IAsyncResult object.

                ReadFromDeviceDelegate deleg =
                    ((ReadFromDeviceDelegate)(ar.AsyncState));

                // Get the IAsyncResult object and the values of other paramaters that the
                // BeginInvoke method passed ByRef.

                deleg.EndInvoke
                    (ref receivedDataBuffer,
                    ref bytesRead,
                    ref success, ar);

                // Display the received data in the form's list box.

                if ((ar.IsCompleted && success))
                {
                    //  Convert the received bytes to a String for display.

                    receivedtext = myEncoder.GetString(receivedDataBuffer);

                    MyMarshalToForm("AddItemToTextBox", receivedtext);
                }
                else
                {
                    MyMarshalToForm("AddItemToTextBox", "The attempt to read bulk data has failed.");
                    myVideoTimer.Enabled = false;
                    myDeviceDetected = false;
                }
                // Enable requesting another transfer.

                MyMarshalToForm("EnableCmdSendandReceiveViaBulkTransfers", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ConButton_Click(object sender, EventArgs e)
        {
            try
            {
                FindMyDevice();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        ///  <summary>
        ///  Called when a WM_DEVICECHANGE message has arrived,
        ///  indicating that a device has been attached or removed.
        ///  </summary>
        ///  
        ///  <param name="m"> A message with information about the device. </param>

        internal void OnDeviceChange(Message m)
        {
            try
            {
                if ((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEARRIVAL))
                {

                    //  If WParam contains DBT_DEVICEARRIVAL, a device has been attached.
                    //  Find out if it's the device we're communicating with.

                    if (myDeviceManagement.DeviceNameMatch(m, myDevicePathName))
                    {
                        DevStatusLable.Text = "My device attached.";
                        FindMyDevice();
                    }

                }
                else if ((m.WParam.ToInt32() ==
                    DeviceManagement.DBT_DEVICEREMOVECOMPLETE))
                {
                    //  If WParam contains DBT_DEVICEREMOVAL, a device has been removed.
                    //  Find out if it's the device we're communicating with.

                    if (myDeviceManagement.DeviceNameMatch(m, myDevicePathName))
                    {

                        //  Set MyDeviceDetected False so on the next data-transfer attempt,
                        //  FindMyDevice() will be called to look for the device 
                        //  and get a new handle.
                        myVideoTimer.Enabled = false;
                        frmMy.myDeviceDetected = false;
                        DevStatusLable.Text = "My device removed.";
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        ///  <summary>
        ///  Initiates a read operation from a bulk IN endpoint.
        ///  To enable reading without blocking the main thread, uses an asynchronous delegate.
        ///  </summary>
        ///  
        ///  <remarks>
        ///  To enable reading more than 64 bytes (with device firmware support), increase bytesToRead.
        ///  </remarks> 

        private void ReadDataViaBulkTransfer()
        {

            IAsyncResult ar = null;
            Byte[] buffer = new Byte[64];
            UInt32 bytesRead = 0;
            UInt32 bytesToRead = System.Convert.ToUInt32(64);
            Boolean success = false;

            //  Define a delegate for the ReadViaBulkTransfer method of WinUsbDevice.

            ReadFromDeviceDelegate MyReadFromDeviceDelegate =
                new ReadFromDeviceDelegate(myWinUsbDevice.ReadViaBulkTransfer);

            try
            {
                //  The BeginInvoke method calls MyWinUsbDevice.ReadViaBulkTransfer to attempt 
                //  to read data. The method has the same parameters as ReadViaBulkTransfer,
                //  plus two additional parameters:
                //  GetReceivedBulkData is the callback routine that executes when 
                //  ReadViaBulkTransfer returns.
                //  MyReadFromDeviceDelegate is the asynchronous delegate object.

                ar = MyReadFromDeviceDelegate.BeginInvoke
                    (System.Convert.ToByte(myWinUsbDevice.myDevInfo.bulkInPipe),
                    bytesToRead,
                    ref buffer,
                    ref bytesRead,
                    ref success,
                    new AsyncCallback(GetReceivedBulkData),
                    MyReadFromDeviceDelegate);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        ///  <summary>
        ///  Initiates sending data via a bulk transfer, then receiving data via a bulk transfer.
        ///  </summary>

        private void SendAndReceiveViaBulkTransfers()
        {
            try
            {
                Boolean success;
                UInt32 bytesToSend;
                String dataToSend = "";
                Byte[] databuffer;
                String formText = "";
                System.Text.ASCIIEncoding myEncoder = new System.Text.ASCIIEncoding();

                //  Get data to send from the textbox.

                dataToSend = sendBox.Text;

                //  Convert the String to a byte array.

                databuffer = myEncoder.GetBytes(dataToSend);
                bytesToSend = Convert.ToUInt32(databuffer.Length);

                // If the device hasn't been detected, was removed, or timed out on a previous attempt
                // to access it, look for the device.

                FindMyDevice();

                if (myDeviceDetected)
                {
                    success = myWinUsbDevice.SendViaBulkTransfer
                        (System.Convert.ToByte(myWinUsbDevice.myDevInfo.bulkOutPipe),
                        ref databuffer,
                        bytesToSend);

                    if (success)
                    {
                        formText = "Data sent via bulk transfer.";
                    }
                    else
                    {
                        formText = "Bulk OUT transfer failed.";
                    }

                    ReadDataViaBulkTransfer();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void LPCDisp_close(object sender, FormClosedEventArgs e)
        {
            try
            {
                myWinUsbDevice.CloseDeviceHandle();

                myDeviceManagement.StopReceivingDeviceNotifications
                    (deviceNotificationHandle);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void LPCDisp_open(object sender, EventArgs e)
        {
            try
            {
                frmMy = this;
                myWinUsbDevice = new WinUsbDevice();
                InitVideoTimer();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void bulkSendBut_Click(object sender, EventArgs e)
        {
            try
            {
                // Don't allow another transfer request until this one completes.
                bulkSendBut.Enabled = false;

                SendAndReceiveViaBulkTransfers();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        ///  <summary>
        ///  Overrides WndProc to enable checking for and handling
        ///  WM_DEVICECHANGE messages.
        ///  </summary>
        ///  
        ///  <param name="m"> A Windows message.
        ///  </param> 
        ///  
        protected override void WndProc(ref Message m)
        {
            try
            {
                // The OnDeviceChange routine processes WM_DEVICECHANGE messages.

                if (m.Msg == DeviceManagement.WM_DEVICECHANGE)
                {
                    OnDeviceChange(m);
                }
                // Let the base form process the message.

                base.WndProc(ref m);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SyncButton_Click(object sender, EventArgs e)
        {
            try
            {
                syncFB = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
 
        }

    }
}
