1. LPC315x RTC Demo application
=========================================
This demonstrates the Alarm functionality of the RTC 
module present in Analog die on LPC315X.

The Application will set the current time in RTC to
1/1/2011 00:00:00. The alarm will be set trigger after 60 seconds
It will print the current time in a loop till the alarm is triggered.  

2. Supported Targets:
=====================
The following target builds are supported for this application.
a. ISRAM 
b. ISRAM with cache enabled
c. SDRAM
d. SDRAM with cache enabled
