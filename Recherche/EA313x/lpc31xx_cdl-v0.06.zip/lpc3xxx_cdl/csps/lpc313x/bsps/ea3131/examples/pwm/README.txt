1. Information about pwm example:
==========================================
This example application demonstrates the usage of PWM modules present on LPC31XX chips.
The PWM driver will be used to control the duty cycles of the output.

The data output can be observed on EA31XX board.
 
2. Supported Targets:
=====================
The following target builds are supported for this application.
a. ISRAM 
b. ISRAM with cache enabled
c. SDRAM
d. SDRAM with cache enabled