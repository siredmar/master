1. Information about wdt example:
==================================
The wdt example demonstrates the Watchdog reset functionality 
LPC313X WDT module. 

The application will reset the board.

2. Supported Targets:
=====================
The following target builds are supported for this application.
a. ISRAM 
b. ISRAM with cache enabled
c. SDRAM
d. SDRAM with cache enabled