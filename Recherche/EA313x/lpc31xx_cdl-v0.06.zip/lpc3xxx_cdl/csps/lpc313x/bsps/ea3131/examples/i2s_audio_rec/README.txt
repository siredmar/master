1. LPC313x Audio capture Demo application:
==========================================
This application will record audio from Microphone connected to Mic socket of EA3131
board, and will playback the recorded stream.

Default recording duration is 8 Seconds. The stream will be:
44100KHz sample rate, stereo samples, 16 bits per sample

By default recording, playback will be performed twice.

2. Supported Targets:
=====================
The following target builds are supported for this application.
a. ISRAM 
b. ISRAM with cache enabled
c. SDRAM
d. SDRAM with cache enabled
