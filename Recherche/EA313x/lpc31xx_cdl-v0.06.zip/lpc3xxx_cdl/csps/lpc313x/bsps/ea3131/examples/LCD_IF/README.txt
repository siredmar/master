1. LCD_IF LCD Interface Example:
================================
The LCD_IF example application demonstrates the 
configuration of LCD interface in LPC31XX Microcontroller.
It provides information on configuring the LCD interface
in 
a. Serial mode 
b. Parallel mode.

NOTE: PLEASE NOTE THAT THE LCD_IF EXAMPLE WILL NOT WORK ON
EA3131 BOARD AS LCD IS MEMORY MAPPED 
(LCD INTERFACE IS NOT USED)  



 