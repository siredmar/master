1. Information about timer_int example:
==========================================
This example application demonstrates the timer capabilities.
The timer will generate an interrupt for every 1 sec & count will 
be displayed on the UART prompt.

2. Supported Targets:
=====================
The following target builds are supported for this application.
a. ISRAM 
b. ISRAM with cache enabled
c. SDRAM
d. SDRAM with cache enabled