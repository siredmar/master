1. Information about pca9532_i2c Example:
==========================================
This example application demonstrates the data transfer using I2C driver. 
The I2C driver will be used to control PCA9532 LEDs (present on EA31XX board).
 
The application will blink the LEDs for about 10 times. 

2. Supported Targets:
=====================
The following target builds are supported for this application.
a. ISRAM 
b. ISRAM with cache enabled
c. SDRAM
d. SDRAM with cache enabled