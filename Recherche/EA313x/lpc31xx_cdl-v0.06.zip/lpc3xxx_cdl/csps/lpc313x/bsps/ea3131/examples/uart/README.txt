1. Information about uart example:
==========================================
This example application demonstrates the UART capabilities.
The data will be displayed on UART prompt.

2. Supported Targets:
=====================
The following target builds are supported for this application.
a. ISRAM 
b. ISRAM with cache enabled
c. SDRAM
d. SDRAM with cache enabled